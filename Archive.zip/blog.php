 <!-- BLOG -->
    <section id="evenementen" name="evenementen">
        <div class="py-5">
            <div class="container mt-5">
                <div class="row">
              
                    <div class="col-md-9">    
                    <h2>Blog</h2>
                        <h4>Evenement 1</h4>
                        <h6>20/09/2020</h6>

                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                        <p>Aantal plaatsen: <b>12</b></p>
                        <p>Nog beschikbare plaatsen: <b>4</b></p>
                        <button type="button" class="btn btn-success btn-sm">Inschrijven</button>
                        <hr>
                    </div>


                    <div class="col-md-9">
                        <h4>Evenement 2</h4>
                        <h6>17/10/2020</h6>

                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                        <p>Aantal plaatsen: <b>12</b></p>
                        <p>Nog beschikbare plaatsen: <b>10</b></p>
                        <button type="button" class="btn btn-success btn-sm">Inschrijven</button>
                        <hr>
                    </div>


                    <div class="col-md-9">
                        <h4>Evenement 3</h4>
                        <h6>3/11/2020</h6>

                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                        <p>Aantal plaatsen: <b>12</b></p>
                        <p>Nog beschikbare plaatsen: <b>10</b></p>
                        <button type="button" class="btn btn-success btn-sm">Inschrijven</button>
                        <hr>
                    </div>

                </div>
            </div>
        </div>
    </section>
